<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            background-color: black;
            color: white;
        }

        input {
            height: 30px;
            width: 250px;
            border-radius: 5px;
            background-color: transparent;
            color: white;
            border-top: transparent;
            border-left: transparent;
            border-right: transparent;
        }

        input:focus {
            background-color: transparent;
            color: white;
            border-top: white;
            border-left: white;
            border-right: white;
        }

        input[type="submit"] {
            margin-top: 10px;
            width: 250px;
            height: 40px;
            font-size: 1.3rem;
            font-weight: 600;
            font-style: oblique;
            border: 1px solid white;
        }

        a {
            color: blue;
        }

        label {
            font-style: italic;
            font-weight: 400;
            font-size: 1.2rem;
        }

        .input {
            margin-block: 10px;
            position: relative;

        }

        svg {
            position: absolute;
            right: 50px;
            bottom: 5px;
        }

        .block {
            border-radius: 10px;
            border: 2px solid white;
            padding-left: 40px;
            padding-right: 30px;
            padding-top: 20px;
            padding-bottom: 10px;
            width: 300px;
            background-color: transparent;
        }

        .error {
            color: red;
        }

        span {
            position: absolute;
            top: 40%;
            right: 30px;
        }
    </style>
</head>

<body>
    <?php
    $firstnameError = $lastnameError = $emailError = $passwordError = null;
    $firstname = $lastname = $email =  $password  = null;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["email"])) {
            $emailError = "email is required";
        } else {
            $email = $_POST["email"];
        }

        if (empty($_POST["password"])) {
            $passwordError = "password is required";
        } else {
            $password = $_POST["password"];
        }
    }

    ?>
    <div class="block">
        <h1>Login</h1>
        <p class="error">* champ obligatoire</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="input">
                <input type="text" name="email" placeholder="email" value="<?php echo $email; ?>">
                <svg width='20px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                    <path d="M1.5 8.67v8.58a3 3 0 003 3h15a3 3 0 003-3V8.67l-8.928 5.493a3 3 0 01-3.144 0L1.5 8.67z" />
                    <path d="M22.5 6.908V6.75a3 3 0 00-3-3h-15a3 3 0 00-3 3v.158l9.714 5.978a1.5 1.5 0 001.572 0L22.5 6.908z" />
                </svg>
                <span class="error">* </span>
            </div>
            <div class="input">
                <input type="text" placeholder="username">
                <svg width="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                    <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clip-rule="evenodd" />
                </svg>
            </div>
            <div class="input">
                <input type="text" placeholder="name">
                <svg width="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                    <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clip-rule="evenodd" />
                </svg>
            </div>

            <div class="input">
                <input type="password" name="password" placeholder="password" value="<?php echo $password; ?>">
                <svg width="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                    <path fill-rule="evenodd" d="M15.75 1.5a6.75 6.75 0 00-6.651 7.906c.067.39-.032.717-.221.906l-6.5 6.499a3 3 0 00-.878 2.121v2.818c0 .414.336.75.75.75H6a.75.75 0 00.75-.75v-1.5h1.5A.75.75 0 009 19.5V18h1.5a.75.75 0 00.53-.22l2.658-2.658c.19-.189.517-.288.906-.22A6.75 6.75 0 1015.75 1.5zm0 3a.75.75 0 000 1.5A2.25 2.25 0 0118 8.25a.75.75 0 001.5 0 3.75 3.75 0 00-3.75-3.75z" clip-rule="evenodd" />
                </svg>
                <span class="error">*</span>
            </div>
            <div class="input">
                <input type="submit" value="Login">
            </div>
            <div class="error">
                <?php
                echo $emailError . '<br>';
                echo $passwordError;
                ?>
            </div>
        </form>
        <div class="changeBlock">
            <p>Mot de passe <a href="#">oublié</a></p>
            <p>Créer un nouveau <a href="#">compte</a></p>
        </div>
    </div>

    <div>
        <?php
        echo $_POST["email"] . '<br>';
        echo $_POST["password"];
        ?>

    </div>
</body>

</html>